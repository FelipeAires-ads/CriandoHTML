Projeto: CriandoHTML
Disciplina: Desenvolvimento Front-End Para Web

Este site foi desenvolvido como parte de um trabalho acadêmico. 
O objetivo é representar uma ONG que ajuda pessoas a recomeçarem e acreditarem em si mesmas novamente.

Páginas:
- index.html: Página inicial com apresentação da ONG.
- projeto.html: Apresenta os projetos sociais desenvolvidos.
- cadastro.html: Formulário para novos voluntários.

Para visualizar o site, extraia o conteúdo do arquivo ZIP e abra 'index.html' em um navegador.
